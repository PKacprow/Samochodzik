var searchData=
[
  ['textview1',['textView1',['../classcom_1_1example_1_1piotrek_1_1myapplicationautko2_1_1_main_activity.html#a46cf4a3b2d6c82baa26736a826c34020',1,'com::example::piotrek::myapplicationautko2::MainActivity']]],
  ['textview2',['textView2',['../classcom_1_1example_1_1piotrek_1_1myapplicationautko2_1_1_main_activity.html#af7917e1718638987b47297fe94b7cfbe',1,'com::example::piotrek::myapplicationautko2::MainActivity']]],
  ['textview3',['textView3',['../classcom_1_1example_1_1piotrek_1_1myapplicationautko2_1_1_main_activity.html#aa66bfcc30bcc4049c31533cdd00741b6',1,'com::example::piotrek::myapplicationautko2::MainActivity']]],
  ['textview4',['textView4',['../classcom_1_1example_1_1piotrek_1_1myapplicationautko2_1_1_main_activity.html#a5f7175d5ce23f0e84fb77d3fb7f8c1c9',1,'com::example::piotrek::myapplicationautko2::MainActivity']]],
  ['textview5',['textView5',['../classcom_1_1example_1_1piotrek_1_1myapplicationautko2_1_1_main_activity.html#a6a2f6ad83a2cca762c259d0e41633dae',1,'com::example::piotrek::myapplicationautko2::MainActivity']]],
  ['touch_5fstate',['touch_state',['../classcom_1_1example_1_1piotrek_1_1myapplicationautko2_1_1_joy_stick_class.html#abe6ddde8ab8ff597e453c0085f76ad8e',1,'com::example::piotrek::myapplicationautko2::JoyStickClass']]]
];
