var searchData=
[
  ['extra_5faddress',['EXTRA_ADDRESS',['../classcom_1_1example_1_1piotrek_1_1myapplicationautko2_1_1_devices.html#af765a0273d2a2974d7c7a7223f54e283',1,'com::example::piotrek::myapplicationautko2::Devices']]]
];
