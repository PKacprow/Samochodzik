var searchData=
[
  ['isbltconnected',['isBltConnected',['../classcom_1_1example_1_1piotrek_1_1myapplicationautko2_1_1_main_activity.html#a95e7745768ade77ad9ae79ccc2234f64',1,'com::example::piotrek::myapplicationautko2::MainActivity']]],
  ['issuccessconnection',['isSuccessConnection',['../classcom_1_1example_1_1piotrek_1_1myapplicationautko2_1_1_main_activity_1_1_connect_blt.html#aee0102c6b0aec9193657c4a76c373e50',1,'com::example::piotrek::myapplicationautko2::MainActivity::ConnectBlt']]]
];
