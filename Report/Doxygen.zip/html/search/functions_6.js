var searchData=
[
  ['paireddeviceslist',['pairedDevicesList',['../classcom_1_1example_1_1piotrek_1_1myapplicationautko2_1_1_devices.html#a83782d33a9d87fcd2b57d1fe1c1c5277',1,'com::example::piotrek::myapplicationautko2::Devices']]],
  ['position',['position',['../classcom_1_1example_1_1piotrek_1_1myapplicationautko2_1_1_joy_stick_class_1_1_draw_canvas.html#adb7bb07a6d5c3edad9f6397663525f01',1,'com::example::piotrek::myapplicationautko2::JoyStickClass::DrawCanvas']]]
];
