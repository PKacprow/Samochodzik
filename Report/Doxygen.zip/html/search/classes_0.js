var searchData=
[
  ['connectblt',['ConnectBlt',['../classcom_1_1example_1_1piotrek_1_1myapplicationautko2_1_1_main_activity_1_1_connect_blt.html',1,'com::example::piotrek::myapplicationautko2::MainActivity']]]
];
