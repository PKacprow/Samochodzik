var searchData=
[
  ['addition_5fiscorrect',['addition_isCorrect',['../classcom_1_1example_1_1piotrek_1_1myapplicationautko_1_1_example_unit_test.html#acd86d962846876b1c8ba6e31d95d50aa',1,'com::example::piotrek::myapplicationautko::ExampleUnitTest']]]
];
