var searchData=
[
  ['mainactivity',['MainActivity',['../classcom_1_1example_1_1piotrek_1_1myapplicationautko2_1_1_main_activity.html',1,'com::example::piotrek::myapplicationautko2']]]
];
