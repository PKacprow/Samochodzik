var searchData=
[
  ['offset',['OFFSET',['../classcom_1_1example_1_1piotrek_1_1myapplicationautko2_1_1_joy_stick_class.html#a2f6ca3129914fa40a7d93f61f2f9aa18',1,'com::example::piotrek::myapplicationautko2::JoyStickClass']]]
];
