var searchData=
[
  ['run',['run',['../classcom_1_1example_1_1piotrek_1_1myapplicationautko2_1_1_main_activity.html#a1b0f2450e55d81947c8c5e5f05e90ab4',1,'com::example::piotrek::myapplicationautko2::MainActivity']]]
];
