var searchData=
[
  ['handler',['handler',['../classcom_1_1example_1_1piotrek_1_1myapplicationautko2_1_1_main_activity.html#af1405c94855c09b8d5a260297d66a1d0',1,'com::example::piotrek::myapplicationautko2::MainActivity']]]
];
