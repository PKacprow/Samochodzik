var searchData=
[
  ['useappcontext',['useAppContext',['../classcom_1_1example_1_1piotrek_1_1myapplicationautko_1_1_example_instrumented_test.html#a151b9feb82e6ee7be641d98bc509872b',1,'com::example::piotrek::myapplicationautko::ExampleInstrumentedTest']]]
];
